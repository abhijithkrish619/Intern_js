// Strings

let fname=prompt("Enter firstname",'');
let mname=prompt("Enter middle name",'');
let lname=prompt("Enter lastname",'');

if(!fname || !mname || !lname){

	alert("Enter all fields");

} else{

let name=fname[0].toUpperCase() +fname.slice(1)
+" "+mname[0].toUpperCase()
+" "+lname.charAt(0).toUpperCase()+lname.slice(1);

alert(name);

}

// Arrays and Objects

function oddEvenClassification(name ,n){

	let arrodd=new Array(n/2);
	let arreven=new Array(n/2);
	let pos1=0,pos2=0;
	for(let x=0;x<=n;x++)
	{

		if(x%2!=0){
			arrodd[pos1] = x;
			pos1++;
		} else {
			arreven[pos2] = x;
			++pos2;
		}


	}
	return {
		name:name,
		odd:arrodd,
		even:arreven
	};

}
let n = prompt("Enter a natural number",'');

n=Number(n);

let tryout = oddEvenClassification("Seperated \n",n)

alert(tryout.name);
alert(`Odd Array ${tryout.odd}`);
alert("Even Array "+tryout.even);

delete tryout.even[0];

alert("Even Array "+tryout.even);

let oddarr=tryout.odd;
oddarr=oddarr.reverse();

alert("Before Sorting "+oddarr);

oddarr.sort( (a, b) => a - b );

alert("After Sorting "+oddarr);

let result = oddarr.reduce(( sum , current ) => sum +current ,0);
alert(result);
function openNav() {
  document.getElementById("mySidepanel").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
}

//recursive
let company = {
  dev: [{name: 'John', salary: 3000}, {name: 'Abhijith', salary: 80000 }],
  sales: {
    sites: [{name: 'Peter', salary: 2000}, {name: 'jith', salary: 18700 }],
    internals: [{name: 'Jack', salary: 1300,name: 'Peter', salary: 25000}]
  }
};

function sumSal(company)
{
	if(Array.isArray(company))
	{
		return company.reduce((previous,current) => 
			previous + current.salary ,0);
	}
	else
	{
		let sum=0;
		for(let dep of Object.values(company)){
			sum+=sumSal(dep);
		}
		return sum;
	}
}
alert(`Salary is ${sumSal(company)}`);


//FACT0RIAL

function Fact(n) {
	if(n == 1){
		return n;
	} else {
		return n * Fact(n-1);
	}

}
let n = prompt("Enter a natural number");
n=Fact(n);
alert(n);

//printling linked list

function printList(list){

	temp=list;
	while(temp){

	alert(temp.value);
	temp=temp.next;
	
	}
}

function reverseList(list){

	if(list.next){
		reverseList(list.next);
	}
	
	alert(list.value);


}
let list={
	value : 1 ,
	next : {
		value :2 ,
		next : {
			value : 3 ,
			next : null
		}
	}
};
printList(list);
alert("Reverse")
reverseList(list);


function hello()
{
	alert(arguments[0]);
}
hello("ge","ss")

let name = "John";

function sayHi() {
  alert("Hi, " + name);
}

sayHi();

name = "Pete";


class Animal {

  constructor(name) {
    this.name = name;
  }

}

class Rabbit extends Animal {
  constructor(name) {
  	super(name);
    this.name = name;
    this.created = Date.now();
  }
}

let rabbit = new Rabbit("White Rabbit"); // Error: this is not defined
alert(rabbit.name);

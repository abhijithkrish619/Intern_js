import React from "react";
import logo from "./logo.svg";
import "./App.css";

class App extends React.Component {
  state = {
    onOff: true,
  };
  styles = {
    margin: "30px",
  };
  expand = (x) => {
    x === true
      ? (document.getElementById("sidepanel").style.width = "15%")
      : (document.getElementById("sidepanel").style.width = "0%");
  };
  sideBar = () => {
    this.setState({ onOff: !this.state.onOff });
    this.expand(this.state.onOff);
  };
  render() {
    return (
      <button className="but" onClick={this.sideBar} id="moveover">
        &#9776;
      </button>
    );
  }
}
export default App;

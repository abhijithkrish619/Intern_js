import React, { Component } from "react";

class Counter extends Component {
  state = {
    count: 0,
  };

  styles = {
    fontSize: 20,
    fontWeight: "bold",
  };

  handleInc = () => {
    this.setState({ count: this.state.count + 1 });
  };

  handleDec = () => {
    this.state.count === 0
      ? this.setState({ count: 0 })
      : this.setState({ count: this.state.count - 1 });
  };
  render() {
    return (
      <div>
        <br></br>
        <button onClick={this.handleInc}>+</button> &nbsp; &nbsp;
        <span>{this.formatCount()}</span> &nbsp; &nbsp;
        <button onClick={this.handleDec}>-</button>
      </div>
    );
  }

  formatCount() {
    return this.state.count === 0 ? "Zero" : this.state.count;
  }
}

export default Counter;

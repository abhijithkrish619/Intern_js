import React, { Component } from "react";
import shoeo from "./shoe1.jpg";
import shoet from "./shoe2.jpg";
import shoes from "./shoe7.jpg";
import jerseyo from "./jersey7.jpg";
import jerseyt from "./jersey6.jpg";
import jerseyth from "./jerseycr7.jpg";
import Counter from "./counter";
class Items extends Component {
  render() {
    return (
      <React.Fragment>
        <div className="products1">
          <img src={shoeo} height="100" width="100"></img>
          <br></br>
          <br></br>
          <Counter />
        </div>
        <br></br>
        <div className="products2">
          <img src={shoet} height="100" width="100"></img>
          <br></br>
          <br></br>
          <Counter />
        </div>
        <div className="products3">
          <img src={shoes} height="100" width="100"></img>
          <br></br>
          <br></br>
          <Counter />
        </div>
        <div className="products4">
          <img src={jerseyo} height="100" width="100"></img>
          <br></br>
          <br></br>
          <Counter />
        </div>
        <div className="products5">
          <img src={jerseyt} height="100" width="100"></img>
          <br></br>
          <br></br>
          <Counter />
        </div>
        <div className="products6">
          <img src={jerseyth} height="100" width="100"></img>
          <br></br>
          <br></br>
          <Counter />
        </div>
      </React.Fragment>
    );
  }
}
export default Items;

let tot =  (a) => a>18 ? alert("he") : alert("bye");
tot(20)

let ask = (question,yes,no) => confirm(question) ? yes() : no()
ask(
    "Hey",
    () => alert("welcome"),
    () => alert("goodbye")
)

let user = {
    name : "Jo",
    age : 15
}
for(let x in user){
    alert(user[x]);
}

let home = prompt("A","home")
let user = {
    [home] : 5
}
alert(user.home);

let user = {

    name : "Jo",
    age : 15,
    canView: true

}
let use = {

}
alert(user.nosuchProperty === undefined);

alert(use.nosuchProperty === undefined);

let map = new Map();

map.set("hi",123);
let i=0;
alert(map.size)
while(i<=10){
    i++;
    input=prompt("enter",'');
    map.set(i,input);
}
for(let items of map){

    alert(items);
}

alert(map.size)

map.forEach( (value, key, map) => {
    alert(`${key}: ${value}`); 
  });

  
 let john = { name: "John" };

 let weakMap = new WeakMap();
 weakMap.set(john, "...");
 alert(weakMap.john);

  let nm= new WeakMap();
  let hey={john:123};
  nm.set(hey);
  alert(nm.john);

  let arr=[1,"aa"];
  alert(arr[0])
  alert(arr[1])



  let pr= new Promise(function(resolve,reject){
      setTimeout(alert("hey"),1000)
      reject(12);
  });
  pr.then(
      result => (alert(result)),
      error => (alert(error+1))
  );
  
 async function f() {

    let promise = new Promise((resolve, reject) => {
      setTimeout(() => resolve("done!"), 1000)
    });
  
    let result = await promise; // wait until the promise resolves (*)
  
    alert(result); // "done!"
  }
  
  f();

  async function f1() {

    let promise = new Promise(function(resolve,reject){
    setTimeout(()=> resolve("timer"),1000)
    });
    
    let res = await promise;
    
    alert(res);
  }
  f1()

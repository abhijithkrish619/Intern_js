import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import * as serviceWorker from "./serviceWorker";

class Toggle extends React.Component {
  constructor(props) {
    super(props);
    this.state = { isToggleOn: false };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.setState((state) => ({
      isToggleOn: !state.isToggleOn,
    }));
  }

  render() {
    return (
      <button onClick={this.handleClick}>
        {this.state.isToggleOn
          ? (document.getElementById("lefts").style.width = "20%")
          : (document.getElementById("lefts").style.width = "0%")}
      </button>
    );
  }
}

ReactDOM.render(<Toggle />, document.getElementById("toph"));

const number = [1, 2, 3, 4, 5, 6];
const listitems = number.map((number) => <li>{number}.</li>);

ReactDOM.render(<ul>{listitems}</ul>, document.getElementById("lefts"));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();

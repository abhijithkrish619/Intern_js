import React from "react";
import logo from "./logo.svg";
import "./App.css";
class App extends React.Component {
  state = {
    count: 1,
  };
  handleClick = () => {
    this.setState({ count: this.state.count + 1 });

    this.expand(this.state.count);
  };
  styles = {
    margin: "2%",
  };
  expand = (x) => {
    x % 2 != 0
      ? (document.getElementById("lefts").style.width = "20%")
      : (document.getElementById("lefts").style.width = "0%");
  };
  render() {
    return (
      <button style={this.styles} onClick={this.handleClick}>
        &#9776;
      </button>
    );
  }
}

export default App;

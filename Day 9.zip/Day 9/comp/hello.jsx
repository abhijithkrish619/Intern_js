import React, { Component } from "react";
class Hello extends Component {
  mess1 = () => {
    document.getElementById("subr1").style.display = "none";
    document.getElementById("subr2").style.display = "block";
  };
  mess2 = () => {
    document.getElementById("subr1").style.display = "block";
    document.getElementById("subr2").style.display = "none";
  };
  render() {
    return (
      <React.Fragment>
        <a onClick={this.mess1}>
          <h3>Create Account</h3>
        </a>
        <a onClick={this.mess2}>
          <h3>Login</h3>
        </a>
      </React.Fragment>
    );
  }
}
export default Hello;
